# CHANGELOG
v0.0.1 (10.2013) - Added netdev_stdlib Mellanox providers
v1.0.0 (01.2014) - Added module types and Mellanox providers + OSPF Mellanox providers
